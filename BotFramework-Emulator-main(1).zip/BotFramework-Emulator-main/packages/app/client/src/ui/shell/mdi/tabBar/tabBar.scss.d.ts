// This is a generated file. Changes are likely to result in being overwritten
export const tabBar: string;
export const draggedOver: string;
export const tabBarTabs: string;
export const tabBarWidgets: string;
export const widget: string;
export const splitWidget: string;
export const presentationWidget: string;
