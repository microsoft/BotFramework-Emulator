// This is a generated file. Changes are likely to result in being overwritten
export const endpointWarning: string;
export const absContentToggle: string;
export const arrowExpanded: string;
export const absContent: string;
export const absTextFieldRow: string;
export const endpointLink: string;
