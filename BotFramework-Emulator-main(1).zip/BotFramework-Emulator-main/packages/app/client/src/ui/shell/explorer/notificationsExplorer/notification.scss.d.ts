// This is a generated file. Changes are likely to result in being overwritten
export const notification: string;
export const notificationMessage: string;
export const notificationTimestamp: string;
export const notificationButtonRow: string;
export const closeIcon: string;
export const innerBorder: string;
