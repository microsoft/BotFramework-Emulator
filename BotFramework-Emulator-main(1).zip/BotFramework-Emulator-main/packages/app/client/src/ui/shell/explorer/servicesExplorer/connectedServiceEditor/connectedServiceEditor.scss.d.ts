// This is a generated file. Changes are likely to result in being overwritten
export const connectedServiceEditor: string;
export const header: string;
export const kvPairContainer: string;
export const kvInputRow: string;
export const kvInputKey: string;
export const kvInputValue: string;
export const noBorder: string;
export const link: string;
export const alert: string;
export const kvSpacing: string;
