// This is a generated file. Changes are likely to result in being overwritten
export const container: string;
export const monacoContainer: string;
export const buttonContainer: string;
export const sendButton: string;
