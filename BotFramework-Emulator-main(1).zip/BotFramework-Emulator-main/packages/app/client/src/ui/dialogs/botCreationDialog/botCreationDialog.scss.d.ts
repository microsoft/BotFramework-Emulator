// This is a generated file. Changes are likely to result in being overwritten
export const botCreateForm: string;
export const endpointWarning: string;
export const multiInputRow: string;
