// This is a generated file. Changes are likely to result in being overwritten
export const buttonRow: string;
export const saveButton: string;
export const keyContainer: string;
export const key: string;
export const show: string;
