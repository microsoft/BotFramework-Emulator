// This is a generated file. Changes are likely to result in being overwritten
export const inputContainer: string;
export const browseButton: string;
export const container: string;
