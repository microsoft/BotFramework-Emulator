// This is a generated file. Changes are likely to result in being overwritten
export const tabManager: string;
export const selectedTab: string;
