// This is a generated file. Changes are likely to result in being overwritten
export const dialogMedium: string;
export const dialogLarge: string;
export const main: string;
export const dialogLink: string;
export const inputContainer: string;
export const encryptKeyCheckBox: string;
export const key: string;
export const actionsList: string;
