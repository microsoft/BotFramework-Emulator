// This is a generated file. Changes are likely to result in being overwritten
export const playbackBar: string;
export const playIcon: string;
