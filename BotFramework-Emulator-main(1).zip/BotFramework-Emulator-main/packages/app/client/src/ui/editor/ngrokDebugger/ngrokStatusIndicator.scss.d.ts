// This is a generated file. Changes are likely to result in being overwritten
export const ngrokStatusIndicator: string;
export const announcement: string;
export const header: string;
export const tunnelHealthIndicator: string;
export const tunnelError: string;
export const tunnelInactive: string;
export const tunnelActive: string;
export const tunnelDetailsList: string;
