// This is a generated file. Changes are likely to result in being overwritten
export const log: string;
export const entry: string;
export const inspected: string;
export const source: string;
export const timestamp: string;
export const srcDst: string;
export const link: string;
export const level0: string;
export const level1: string;
export const level2: string;
export const level3: string;
export const spaced: string;
